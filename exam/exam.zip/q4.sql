-- COMP3311 12s1 Exam Q4
-- The Q4 view must have attributes called (team1,team2,matches)

drop view if exists Q4;
create view Q4
as
... SQL code for view goes here ...
;


-- COMP3311 12s1 Exam Q3
-- The Q3 view must have attributes called (team,players)

drop view if exists Q3;
create view Q3
as
... SQL code for view goes here ...
;

-- COMP3311 12s1 Exam Q5
-- The Q5 view must have attributes called (team,reds,yellows)

drop view if exists Q5;
create view Q5
as
... SQL code for view goes here ...
;

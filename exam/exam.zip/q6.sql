-- COMP3311 12s1 Exam Q6
-- The Q6 view must have attributes called
-- (location,date,team1,goals1,team2,goals2)

drop view if exists Q6;
create view Q6
as
... SQL code for view goes here ...
;
